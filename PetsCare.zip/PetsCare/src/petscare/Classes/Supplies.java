/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petscare.Classes;

/**
 *
 * @author Maryam Tariq
 */
public class Supplies extends Product{

    public Supplies(String name, double price, String type, int quantity)
    {
        super(name, price, type, quantity);
    }

    @Override
    public String toString()
    {
        return super.toString();
    }
    
}
