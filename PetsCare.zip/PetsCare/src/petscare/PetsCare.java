/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petscare;

import java.util.ArrayList;
import javax.swing.JFrame;
import petscare.Classes.Product;

/**
 *
 * @author Maryam Tariq
 */
public class PetsCare {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Login login = new Login();
        login.setVisible(true); 
    }
    
}
